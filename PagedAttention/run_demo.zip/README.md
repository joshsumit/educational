
# Educational Paged Attention Walkthrough Repo

This repo is a **small, fully-commented educational implementation** of:

- transformer decoder attention
- Q / K / V projection
- head splitting and transpose
- causal masking during prefill
- paged KV cache
- physical block allocation
- logical token -> physical block mapping
- page-table walk during decode
- multi-sequence serving without padding
- educational continuous / inflight batching

## Files

- `run_demo.py` - entry point
- `decoder.py` - decoder layer walkthrough
- `attention.py` - attention math with detailed prints
- `paged_kv_cache.py` - multi-sequence paged KV cache
- `page_allocator.py` - physical block allocator
- `tensor_utils.py` - narrated prints, bytes, simple FLOP helpers
- `concepts.md` - conceptual explanation

## Run

```bash
python run_demo.py
```

## Shape conventions

- `B` = batch size for one dispatched tensor
- `S` = query sequence length for the current call
- `T` = total context tokens for one sequence already in cache
- `D` = model hidden dimension
- `H` = number of attention heads
- `Dk` = per-head hidden dimension where `Dk = D / H`

Important transitions:

1. Input embeddings: `[B, S, D]`
2. After Q/K/V projection: `[B, S, D]`
3. After reshape: `[B, S, H, Dk]`
4. After transpose: `[B, H, S, Dk]`
5. Gathered cache per sequence: `[H, T, Dk]`
6. Attention scores: `[B, H, S, T]`
7. Attention output per head: `[B, H, S, Dk]`
8. Merged heads: `[B, S, D]`
